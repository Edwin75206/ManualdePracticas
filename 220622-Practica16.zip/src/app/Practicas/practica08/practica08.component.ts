import { Component } from '@angular/core';

@Component({
  selector: 'app-practica08',
  templateUrl: './practica08.component.html',
  styleUrls: ['./practica08.component.css']
})
export class Practica08Component {

  texto=''
}
