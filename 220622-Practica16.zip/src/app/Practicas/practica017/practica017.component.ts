import { Component } from '@angular/core';

@Component({
  selector: 'app-practica017',
  templateUrl: './practica017.component.html',
  styleUrls: ['./practica017.component.css']
})
export class Practica017Component {

}
