import { Component } from '@angular/core';

@Component({
  selector: 'app-practica04',
  templateUrl: './practica04.component.html',
  styleUrls: ['./practica04.component.css']
})
export class Practica04Component {

}
