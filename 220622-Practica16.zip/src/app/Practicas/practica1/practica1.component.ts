import { Component } from '@angular/core';

@Component({
  selector: 'app-practica1',
  templateUrl: './practica1.component.html',
  styleUrls: ['./practica1.component.css']
})
export class Practica1Component {

}
