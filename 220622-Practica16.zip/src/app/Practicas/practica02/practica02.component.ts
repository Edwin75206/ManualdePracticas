import { Component } from '@angular/core';

@Component({
  selector: 'app-practica02',
  templateUrl: './practica02.component.html',
  styleUrls: ['./practica02.component.css']
})
export class Practica02Component {
  title = 'ManualdePracticas';

}
